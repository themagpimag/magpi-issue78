OFFSETX = 368
OFFSETY = 200
mapBlocks = ["map1c","map2c"]
mapHeight = [0,32]

def draw(): # Pygame Zero draw function
    screen.fill((0, 0, 0))
    drawMap()

def drawMap():
    for x in range(0, 12):
        for y in range(0, 12):
            screen.blit(mapBlocks[mapData[x][y]], ((x*32)-(y*32)+OFFSETX,
                        (y*16)+(x*16)+OFFSETY - mapHeight[mapData[x][y]]))
