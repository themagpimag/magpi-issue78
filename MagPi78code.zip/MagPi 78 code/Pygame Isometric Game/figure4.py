def update(): # Pygame Zero update function
    global player
    if player["moveDone"] == True:
        if keyboard.left:
            doMove(player, -1, 0)
        if keyboard.right:
            doMove(player, 1, 0)
        if keyboard.up:
            doMove(player, 0, -1)
        if keyboard.down:
            doMove(player, 0, 1)
    updateBall(player)

def doMove(p, x, y):
    if 0 <= (p["x"]+x) < mapInfo["width"] and 0 <= (p["y"]+y) < mapInfo["height"]:
        if mapData[p["x"]+x][p["y"]+y] == 0:
            p.update({"queueX":x, "queueY":y, "moveDone":False})

