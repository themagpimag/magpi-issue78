# This code is near the top of our program

player = {"x":0, "y":3, "frame":0, "sx":0, "sy":0,
          "moveX":0, "moveY":0, "queueX":0, "queueY":0,
          "moveDone":True, "movingNow":False, "animCounter":0}


# This code goes in the drawMap() function inside the y loop

            if x == player["x"] and y == player["y"]:
                if player["sx"] == 0:
                   player["sx"] = (x*32)-(y*32)+OFFSETX
                   player["sy"] = (y*16)+(x*16)+OFFSETY-32
                screen.blit("ball"+str(player["frame"]), (player["sx"], player["sy"]))
                
